<?php
echo '
        <footer class="tm-footer">

                <div>
                </div>

                <p class="tm-copyright-text">Copyright &copy; 2019 UFBA - IHAC

                </p>

            </footer>';
?>
